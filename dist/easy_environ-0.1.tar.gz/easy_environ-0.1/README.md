# Easy Environment
A python library to rapidly set, get, and view local environment variables (currently only for bash and zsh shells in unix).

[ [PyPi Link](https://pypi.org/project/easy-environ/0.1/) ]
